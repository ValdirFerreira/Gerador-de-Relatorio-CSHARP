﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gerarador.Relatorio;

namespace Gerador.Relatorio
{
    public class Mapa : IDisposable
    {
        #region [ Constructors ]


        /// <summary>
        /// Construtor Padrão da Classe    
        /// </remarks>
        public Mapa()
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Destructors ]
        /// <summary>
        /// Destrutor da classe
        /// </summary>
        ~Mapa()
        {
            Dispose();
        }

        /// <summary>
        /// Método para limpeza das variáveis da classe
        /// </summary>
        public void Dispose()
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Properties ]
        /// <summary>
        /// Identificador
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Nome
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public IList<MapaConhecimentoArea> Areas { get; set; }

        public IDictionary<string, string> Conhecimentos { get; set; }

        public IDictionary<string, string> Observacoes { get; set; }

        public IDictionary<string, string> Prioridades { get; set; }

        #endregion


        #region [ Internal Methods ]
        /// <summary>
        /// Método que limpa as variáveis da classe
        /// </summary>
        private void LimpaVariaveis()
        {
            Id = 0;
            Nome = string.Empty;

        }
        #endregion

    }
}
