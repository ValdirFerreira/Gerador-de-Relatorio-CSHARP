﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gerador.Relatorio
{
    public class UsuarioConhecimento
    {

        public string Cpf { get; set; }
        /// <summary>
        /// Nome
        /// </summary>
        public string Disciplina { get; set; }
    }
}
