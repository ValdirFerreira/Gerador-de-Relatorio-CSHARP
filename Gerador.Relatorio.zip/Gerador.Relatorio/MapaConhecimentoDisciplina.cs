﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Ciatech.Atena;
using Microsoft.ApplicationBlocks.Data;
using Gerador.Relatorio;
namespace Gerador.Relatorio
{

    public class MapaConhecimentoDisciplina : IDisposable
    {

        #region [ Properties ]
        /// <summary>
        /// Identificador
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Nome
        /// </summary>
        public string Nome { get; set; }
        /// <summary>
        /// Descrição da Disciplina
        /// </summary>
        public string Descricao { get; set; }

        public string Conhecimentos { get; set; }

        public string Observacoes { get; set; }

        public string Prioridades { get; set; }

        public IList<MapaConhecimentoObservacoes> Titulo { get; set; }


        #endregion

        #region [ Constructors ]

        public MapaConhecimentoDisciplina()
        {
        }

        /// <summary>
        /// Construtor Padrão da Classe       
        /// </remarks>
        public MapaConhecimentoDisciplina(string databaseConn, int usuarioLogId, string usuarioIP)
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Destructors ]
        /// <summary>
        /// Destrutor da classe
        /// </summary>
        ~MapaConhecimentoDisciplina()
        {
            Dispose();
        }

        /// <summary>
        /// Método para limpeza das variáveis da classe
        /// </summary>
        public void Dispose()
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Internal Methods ]
        /// <summary>
        /// Método que limpa as variáveis da classe
        /// </summary>
        private void LimpaVariaveis()
        {
            Id = 0;
            Nome = string.Empty;
        }
        #endregion
    }


}
