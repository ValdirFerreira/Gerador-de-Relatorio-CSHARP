﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.Drawing;
using System.Net;
using System.IO;
using Gerador.Relatorio;


namespace Gerarador.Relatorio
{
    public class Notificador
    {
        MapaConhecimentoTotalRelatorio _MapaConhecimentoTotalRelatorio = new MapaConhecimentoTotalRelatorio();

        private static string connectionString;

        static void Main(string[] args)
        {
            RecuperaConexao();

            GerarRelatorio();
        }

        #region [Métodos Internos]
        private static void RecuperaConexao()
        {
            var connectionStringSettings = ConfigurationManager.ConnectionStrings["CanalEducacaoConnection"];
            connectionString = connectionStringSettings.ConnectionString;
        }


        private static void GerarRelatorio()
        {
            Console.WriteLine("1 - Aguarde, Iniciando o processamento.\n");
            var MapaTotal = new MapaConhecimentoTotalRelatorio(connectionString);
            var Lista = MapaTotal.RelatorioLista();
            GerarExcel(Lista);
        }
        #endregion


        #region [Métodos Customizados]

        public static void GerarExcel(IList<MapaConhecimentoTotalRelatorio> itens)
        {
            List<UsuarioConhecimento> _UsuarioConhecimento = new List<UsuarioConhecimento>();
            List<Mapa> ListadeMapas = new List<Mapa>();

            Console.WriteLine("2 - Aguarde, Gerando Titulos do Relatório.\n");
            var excel = new ExcelPackage();
            var workSheet = excel.Workbook.Worksheets.Add(string.Format("Relatório por Conhecimento"));

            var row = 4;


            RenderizaTitulo(workSheet, row, 1, "Nome do Funcionário", ExcelHorizontalAlignment.Left);
            RenderizaTitulo(workSheet, row, 2, "Matrícula");
            RenderizaTitulo(workSheet, row, 3, "CPF");
            RenderizaTitulo(workSheet, row, 4, "Data de Admissão");
            RenderizaTitulo(workSheet, row, 5, "Local de Trabalho", ExcelHorizontalAlignment.Left);
            RenderizaTitulo(workSheet, row, 6, "Nome do Gestor", ExcelHorizontalAlignment.Left);
            RenderizaTitulo(workSheet, row, 7, "Matrícula do Gestor");

            var column = 8;
            var qtdConhecimentos = 0;

            var mapas = itens.SelectMany(m => m.Mapas);

            // CAREGAR MAPAS SEM DUPLICIDADES
            foreach (var itemMapa in mapas)
            {
                bool validMap = true;
                foreach (var item in ListadeMapas.ToList())
                {
                    if (item.Id == itemMapa.Id)
                        validMap = false;
                }

                if (validMap)
                    ListadeMapas.Add(itemMapa);
            }

            var qtdMapas = ListadeMapas.Count;
            var qtdContadas = 1;
            foreach (var Mapas in ListadeMapas)
            {
                Console.Clear();
                Console.WriteLine("3 - Aguarde, Gerando colunas do Relatório. :" + qtdContadas + " de " + qtdMapas.ToString() + "\n");

                int EndCell = column + (Mapas.Areas.SelectMany(d => d.Disciplinas).Count() * 2) - 1;
                if (Mapas.Areas.Count > 0)
                {

                    using (var range = workSheet.Cells[1, column, 1, EndCell])
                    {
                        range.Merge = true;
                        range.Value = Mapas.Nome;
                        range.Style.Font.Bold = true;
                        range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
                        range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(191, 191, 191));
                        range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        range.Style.Font.Size = 10;
                    }


                    foreach (var Areas in Mapas.Areas)
                    {
                        using (var range = workSheet.Cells[2, column, 2, column + (Areas.Disciplinas.Count * 2) - 1])
                        {
                            range.Merge = true;
                            range.Value = Areas.Nome;
                            range.Style.Font.Bold = true;
                            range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
                            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(191, 191, 191));
                            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                            range.Style.Font.Size = 10;
                        }


                        foreach (var Disciplinas in Areas.Disciplinas)
                        {
                            using (var range = workSheet.Cells[3, column, 3, column + Disciplinas.Titulo.Count - 1])
                            {
                                range.Merge = true;
                                range.Value = Disciplinas.Nome;
                                range.Style.Font.Bold = true;
                                range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
                                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                                range.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(191, 191, 191));
                                range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                                range.Style.Font.Size = 10;
                            }


                            var linha = 5;
                            foreach (var Titulo in Disciplinas.Titulo)
                            {
                                RenderizaTitulo(workSheet, 4, column, Titulo.Titulo);

                                foreach (var item in itens)
                                {
                                    var propriedade = string.Empty;

                                    var mapa = item.Mapas.FirstOrDefault(x => x.Nome.Equals(Mapas.Nome));
                                    if (mapa == null)
                                    {
                                        RenderizaItem(workSheet, linha, column, "-", ExcelHorizontalAlignment.Center);
                                        linha++;
                                        continue;
                                    }

                                    var area = mapa.Areas.FirstOrDefault(x => x.Nome.Equals(Areas.Nome));
                                    if (area == null)
                                    {
                                        RenderizaItem(workSheet, linha, column, "-", ExcelHorizontalAlignment.Center);
                                        linha++;
                                        continue;
                                    }

                                    var disciplina = area.Disciplinas.FirstOrDefault(x => x.Nome.Equals(Disciplinas.Nome));
                                    if (disciplina == null)
                                    {
                                        RenderizaItem(workSheet, linha, column, "-", ExcelHorizontalAlignment.Center);
                                        linha++;
                                        continue;
                                    }

                                    if (Titulo.Titulo == "Prioridade")
                                    {
                                        RenderizaItem(workSheet, linha, column, disciplina.Prioridades, ExcelHorizontalAlignment.Center);
                                    }
                                    else if (Titulo.Titulo == "Conhecimento")
                                    {
                                        RenderizaItem(workSheet, linha, column, disciplina.Conhecimentos, ExcelHorizontalAlignment.Center);

                                        if (disciplina.Conhecimentos == "Sim" || disciplina.Conhecimentos == "Não")
                                        {
                                            _UsuarioConhecimento.Add(new UsuarioConhecimento { Cpf = item.CPF, Disciplina = disciplina.Conhecimentos });

                                        }
                                    }

                                    linha++;
                                }

                                linha = 5;
                                column++;

                            }
                        }
                    }
                }

                qtdContadas++;
            }


            var qtdColuna = column;
            var qtdLinha = row + 1;

            RenderizaTitulo(workSheet, row, column, "Quantidade de Disciplinas");
            column++;
            RenderizaTitulo(workSheet, row, column, "Conhecimento das Disciplinas");
            column++;
            RenderizaTitulo(workSheet, row, column, "% Conhecimento das Disciplinas");

            var conhecimentos = 1;
            var qtditens = itens.Count;

            foreach (var item in itens)
            {
                Console.Clear();
                Console.WriteLine("3 - Aguarde, Somando conhecimentos: " + conhecimentos + " de " + qtditens + "\n");
                Double qtdDisciplina = 0;
                Double qtdConhecimento = 0;
                foreach (var itemUser in _UsuarioConhecimento)
                {
                    if (itemUser.Cpf == item.CPF)
                    {
                        qtdDisciplina++;
                        if (itemUser.Disciplina == "Sim")
                            qtdConhecimento++;

                    }
                }


                RenderizaItem(workSheet, qtdLinha, qtdColuna, qtdDisciplina.ToString(), ExcelHorizontalAlignment.Center);
                RenderizaItem(workSheet, qtdLinha, qtdColuna + 1, qtdConhecimento.ToString(), ExcelHorizontalAlignment.Center);

                Double porcentagem = 0;
                if (qtdConhecimento > 0 && qtdDisciplina > 0)
                    porcentagem = Convert.ToDouble(qtdConhecimento / qtdDisciplina);

                RenderizaItem(workSheet, qtdLinha, qtdColuna + 2, porcentagem, ExcelHorizontalAlignment.Center, true);
                qtdLinha++;

                conhecimentos++;
            }

            row++;

            column = 8;
            foreach (var item in itens)
            {
                RenderizaItem(workSheet, row, 1, item.NomeDoFuncionario, ExcelHorizontalAlignment.Left);
                RenderizaItem(workSheet, row, 2, item.Matricula);
                RenderizaItem(workSheet, row, 3, item.CPF);
                RenderizaItem(workSheet, row, 4, item.DataDeAdmissao != DateTime.MinValue
                                                     ? item.DataDeAdmissao.ToString("dd/MM/yyyy")
                                                     : string.Empty);
                RenderizaItem(workSheet, row, 5, item.LocalDeTrabalho, ExcelHorizontalAlignment.Left);
                RenderizaItem(workSheet, row, 6, item.NomeDoGestor, ExcelHorizontalAlignment.Left);
                RenderizaItem(workSheet, row, 7, item.MatriculaDoGestor);

                row++;
            }


            using (var range = workSheet.Cells[1, 1, itens.Count + 3, column])
            {
                range.AutoFitColumns();
                range.Style.Font.Size = 10;
            }

            Console.WriteLine("4 - Aguarde, Salvando Relatório.\n");

            #region Configurações
            // Definindo variáveis

            string REPORTINGDIRETORIO = "ReportingDiretorio";
            string REPORTINGEXTANSAO = "ReportingExtensao";

            //Definindo relatórios       

            string Diretorio = ConfigurationManager.AppSettings[REPORTINGDIRETORIO].ToString();
            string Extensao = ConfigurationManager.AppSettings[REPORTINGEXTANSAO].ToString();


            #endregion

            string file = Diretorio + Extensao;
            File.WriteAllBytes(file, excel.GetAsByteArray());
            //var process = System.Diagnostics.Process.Start(file);

        }

        static void RenderizaTitulo(ExcelWorksheet workSheet, int row, int column, object value, ExcelHorizontalAlignment align = ExcelHorizontalAlignment.Center)
        {
            workSheet.Cells[row, column].Value = value;
            workSheet.Cells[row, column].Style.Font.Bold = true;
            workSheet.Cells[row, column].Style.Border.BorderAround(ExcelBorderStyle.Thin);
            workSheet.Cells[row, column].Style.Fill.PatternType = ExcelFillStyle.Solid;
            workSheet.Cells[row, column].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(242, 242, 242));
            workSheet.Cells[row, column].Style.HorizontalAlignment = align;
            workSheet.Cells[row, column].Style.Font.Size = 10;

        }

        static void RenderizaItem(ExcelWorksheet workSheet, int row, int column, object value, ExcelHorizontalAlignment align = ExcelHorizontalAlignment.Center, bool formatPercent = false)
        {
            workSheet.Cells[row, column].Value = value;
            workSheet.Cells[row, column].Style.Border.BorderAround(ExcelBorderStyle.Thin);
            workSheet.Cells[row, column].Style.HorizontalAlignment = align;
            workSheet.Cells[row, column].Style.Font.Size = 10;

            if (!formatPercent) return;
            workSheet.Cells[row, column].Value = (Double)value;
            workSheet.Cells[row, column].Style.Numberformat.Format = "0.00%";
        }


        static void RenderizaTituloMapa(ExcelWorksheet workSheet, int row, int column, object value, ExcelHorizontalAlignment align = ExcelHorizontalAlignment.Center)
        {
            workSheet.Cells[row, column].Value = value;
            workSheet.Cells[row, column].Style.Font.Bold = true;
            workSheet.Cells[row, column].Style.Border.BorderAround(ExcelBorderStyle.Thin);
            workSheet.Cells[row, column].Style.Fill.PatternType = ExcelFillStyle.Solid;
            workSheet.Cells[row, column].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(191, 191, 191));
            workSheet.Cells[row, column].Style.HorizontalAlignment = align;
            workSheet.Cells[row, column].Style.Font.Size = 10;

        }

       

        #endregion

    }

}
