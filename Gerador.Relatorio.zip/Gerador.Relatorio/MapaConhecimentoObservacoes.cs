﻿using System;
using System.Collections.Generic;
using System.Text;
using Ciatech.Atena;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using Gerador.Relatorio;

namespace Gerador.Relatorio
{
    public class MapaConhecimentoObservacoes : IDisposable
    {

        #region [ Properties ]
        public string Titulo { get; set; }

        public IDictionary<string, string> Conhecimentos { get; set; }

        public IDictionary<string, string> Observacoes { get; set; }

        public IDictionary<string, string> Prioridades { get; set; }     

        #endregion

        #region [ Constructors ]

        public MapaConhecimentoObservacoes()
        {
        }


        #endregion

        #region [ Destructors ]
        /// <summary>
        /// Destrutor da classe
        /// </summary>
        ~MapaConhecimentoObservacoes()
        {
            Dispose();
        }

        /// <summary>
        /// Método para limpeza das variáveis da classe
        /// </summary>
        public void Dispose()
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Internal Methods ]
        /// <summary>
        /// Método que limpa as variáveis da classe
        /// </summary>
        private void LimpaVariaveis()
        {
            Titulo = string.Empty;
        }
        #endregion
    }
}
