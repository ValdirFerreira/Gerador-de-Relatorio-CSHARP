﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Ciatech.Atena;
using Microsoft.ApplicationBlocks.Data;
using Gerador.Relatorio;


namespace Gerarador.Relatorio
{
    public class MapaConhecimentoTotalRelatorio
    {

        #region [Entity]

        public int Id { get; set; }

        public string NomeDoFuncionario { get; set; }

        public string Matricula { get; set; }

        public string CPF { get; set; }

        public DateTime DataDeAdmissao { get; set; }

        public string LocalDeTrabalho { get; set; }

        public string NomeDoGestor { get; set; }

        public string MatriculaDoGestor { get; set; }

        public string bitConhecimento { get; set; }

        public string prioridadeDesenvolvimento { get; set; }

        public IList<Mapa> Mapas { get; set; }

        #endregion

        #region [Variáveis Privadas]
        /// <summary>
        /// string de conexão
        /// </summary>
        private string databaseConn;

        /// <summary>
        /// ojbeto de criptografia
        /// </summary>
        private Criptografia criptografia;
        #endregion

        #region [Propriedades]
        /// <summary>
        /// String com a string de conexão com o banco de dados
        /// </summary>
        public string DatabaseConn
        {
            set
            {
                databaseConn = criptografia.Descriptografa(value)
                                   ? criptografia.strValorDescriptografado
                                   : string.Empty;
            }
        }

        /// <summary>
        /// Aviso ao usuário
        /// </summary>
        public string Aviso { get; set; }
        #endregion

        #region [Construtores]
        /// <summary>
        /// 
        /// </summary>
        public MapaConhecimentoTotalRelatorio()
        {
        }

        /// <summary>
        /// Construtor Padrão da Classe com Log
        /// </summary>
        /// <remarks>
        /// Descriptgrafa a string de conexão com o banco de dados e inicia as variáveis da classe com valores padrão
        /// </remarks>
        public MapaConhecimentoTotalRelatorio(string strDatabaseConn)
        {
            criptografia = new Criptografia();
            // Decriptografia da string de conexão
            DatabaseConn = strDatabaseConn;

            Aviso = string.Empty;
        }
        #endregion

        #region [Métodos Publicos]
        /// <summary>
        /// Relatório por Todos Conhecimentos
        /// </summary>
        public IList<MapaConhecimentoTotalRelatorio> RelatorioLista()
        {

            MapaConhecimentoTotalRelatorio item = null;
            MapaConhecimentoArea area = null;
            Mapa mapa = null;
            MapaConhecimentoDisciplina Disciplinas = null;
            MapaConhecimentoObservacoes Titulo = null;

            var value = "";

            var relatorio = new List<MapaConhecimentoTotalRelatorio>();

            using (var reader = (SqlHelper.ExecuteReader(databaseConn,
                                                         CommandType.StoredProcedure,

                                                         "[MapaConhecimento].[Relatorio_ListamapaTotal]"
                                                         )))
            {
                while (reader.Read())
                {
                    if (item == null || item.Id != Convert.ToInt32(reader["idUsuario"]))
                    {
                        item = new MapaConhecimentoTotalRelatorio
                        {
                            Id = Convert.ToInt32(reader["idUsuario"]),
                            NomeDoFuncionario = reader["strNomeCompleto"].ToString(),
                            Matricula = reader["strCodContrato"].ToString(),
                            CPF = reader["strCPF"].ToString(),
                            DataDeAdmissao = reader["dtAdmissao"] != DBNull.Value
                                                 ? Convert.ToDateTime(reader["dtAdmissao"])
                                                 : DateTime.MinValue,
                            LocalDeTrabalho = reader["strNmOrganizacao"].ToString(),
                            NomeDoGestor = reader["strNomeCompletoGestor"].ToString(),
                            MatriculaDoGestor = reader["strMatriculaGestor"].ToString(),
                            prioridadeDesenvolvimento = reader["prioridadeDesenvolvimento"].ToString(),
                            bitConhecimento = reader["bitConhecimento"] != DBNull.Value
                                            ? Convert.ToBoolean(reader["bitConhecimento"]) ? "Sim" : "Não"
                                            : " - ",

                            Mapas = new List<Mapa>(),

                        };

                        relatorio.Add(item);
                    }

                    // INSERE MAPAS

                    bool validMapas = true;
                    foreach (var itemMapa in item.Mapas)
                    {
                        if (itemMapa.Nome == reader["strNmMapa"].ToString())
                            validMapas = false;
                    }


                    if (mapa == null || mapa.Nome != reader["strNmMapa"].ToString())
                    {
                        mapa = new Mapa
                        {
                            Id = Convert.ToInt32(reader["idMapa"]),
                            Nome = reader["strNmMapa"].ToString(),
                            Areas = new List<MapaConhecimentoArea>(),

                        };
                        if (validMapas)
                            item.Mapas.Add(mapa);
                    }


                    // INSERE AREAS

                    bool validAreas = true;
                    foreach (var itemArea in mapa.Areas)
                    {
                        if (itemArea.Nome == reader["strNmArea"].ToString())
                            validAreas = false;
                    }


                    if (area == null || area.Nome != reader["strNmArea"].ToString())
                    {

                        area = new MapaConhecimentoArea
                        {
                            Id = Convert.ToInt32(reader["idArea"]),
                            Nome = reader["strNmArea"].ToString(),
                            Disciplinas = new List<MapaConhecimentoDisciplina>(),
                        };

                        if (validAreas)
                            mapa.Areas.Add(area);
                    }


                    // INSERE DISCIPLINAS

                    if (Disciplinas == null || Disciplinas.Nome != reader["strNmDisciplina"].ToString())
                    {

                        Disciplinas = new MapaConhecimentoDisciplina
                        {
                            Id = Convert.ToInt32(reader["idDisciplina"]),
                            Nome = reader["strNmDisciplina"].ToString(),
                            Titulo = new List<MapaConhecimentoObservacoes>()
                        };

                        area.Disciplinas.Add(Disciplinas);
                    }

                    var prioridadeDisciplina = reader["prioridadeDesenvolvimento"] != DBNull.Value
                            ? reader["prioridadeDesenvolvimento"].ToString()
                            : " - ";
                    Disciplinas.Prioridades = reader["prioridadedesenvolvimento"].ToString();

                    var possuiConhecimento = reader["bitConhecimento"] != DBNull.Value
                                            ? Convert.ToBoolean(reader["bitConhecimento"]) ? "Sim" : "Não"
                                            : " - ";
                    Disciplinas.Conhecimentos = possuiConhecimento;


                    // COLUNAS PROPRIEDADE E CONHECIMENTO

                    for (int i = 0; i < 2; i++)
                    {
                        if (i == 0)
                            Titulo = new MapaConhecimentoObservacoes
                            {
                                Titulo = "Prioridade"
                            };

                        else
                            Titulo = new MapaConhecimentoObservacoes
                            {
                                Titulo = "Conhecimento"
                            };


                        Disciplinas.Titulo.Add(Titulo);
                    }
                }
            }

            return relatorio;
        }

        #endregion

    }

}
