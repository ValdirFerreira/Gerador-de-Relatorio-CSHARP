﻿using System;
using System.Collections.Generic;
using System.Text;
using Ciatech.Atena;
using System.Data.SqlClient;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using Gerador.Relatorio;


namespace Gerarador.Relatorio
{
    public class MapaConhecimentoArea : IDisposable
    {

        #region [ Properties ]
        /// <summary>
        /// Identificador
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Nome
        /// </summary>
        public string Nome { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public IList<MapaConhecimentoDisciplina> Disciplinas { get; set; }

        #endregion

        #region [ Constructors ]

        public MapaConhecimentoArea()
        {
        }

        /// <summary>
        /// Construtor Padrão da Classe       
        /// </remarks>
        public MapaConhecimentoArea(string databaseConn, int usuarioLogId, string usuarioIP)
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Destructors ]
        /// <summary>
        /// Destrutor da classe
        /// </summary>
        ~MapaConhecimentoArea()
        {
            Dispose();
        }

        /// <summary>
        /// Método para limpeza das variáveis da classe
        /// </summary>
        public void Dispose()
        {
            LimpaVariaveis();
        }
        #endregion

        #region [ Internal Methods ]
        /// <summary>
        /// Método que limpa as variáveis da classe
        /// </summary>
        private void LimpaVariaveis()
        {
            Id = 0;
            Nome = string.Empty;
        }
        #endregion
    }
}
